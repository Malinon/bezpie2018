#Jakub Malinowski

module blocksys

export gausSimple, LUChoiceSolve, gausChoice, LUChoice, LUSimple, LUSimpleSolve

function read_matrix(name)
    temp = readdlm(name,' ');
    n = Int(temp[1,1])

    l = Int(temp[1,2])
    temp = [temp[2:size(temp,1),i] for i in 1:size(temp,2)]
    v = Int(n/l)
    #sztuczne dozerowanie
    lenek = (3*n-2*l)*l#2*n*l
    vall = zeros(lenek)

    rows= Vector{Int}(lenek)


    columns= Vector{Int}(lenek)

	ii = 1

	for kk = 1:(2*l)
		for kkk=1:l
			rows[ii] =  kkk
			columns[ii] = kk
			ii = ii + 1
		end
	end


	for k=2:(v-1)
		bw=(k-2)*l
		bk=(k-1)*l
		for kk = 1:(3*l)
			for kkk=1:l

				rows[ii] = bw + kkk
    			columns[ii] = bk + kk
		
				ii = ii + 1
			end
		end
	end




	bw = n-l
	bk = n-2*l

	for kk = 1:(2*l)
		for kkk=1:l
			rows[ii] = bw+  kkk
			columns[ii] =bk+ kk
			ii = ii + 1
		end
	end

    A = sparse(rows,columns,vall)

    r =size(temp[1],1)
	
    for iii = 1:r
    	A[temp[1][iii],temp[2][iii]] = temp[3][iii]
    end
	

	
    return A,n,l
end


function read_matrix_swap(name)
    temp = readdlm(name,' ');
    n = Int(temp[1,1])

    l = Int(temp[1,2])
    temp = [temp[2:size(temp,1),i] for i in 1:size(temp,2)]

    v = Int(n/l)
    #sztuczne dozerowanie
    lenek = (3*n-2*l)*l+(v-2)*l
    vall = zeros(lenek)

    rows= Vector{Int}(lenek)


    columns= Vector{Int}(lenek)
 	ii = 1

	for kk = 1:(2*l)
		for kkk=1:l
			rows[ii] =  kkk
			columns[ii] = kk
			ii = ii + 1
		end
	end


	for k=2:(v-1)
		bw=(k-2)*l
		bk=(k-1)*l
		for kk = 1:(3*l)
			for kkk=1:l

				rows[ii] = bw + kk
    			columns[ii] = bk + kkk
		
				ii = ii + 1
			end
		end
	end




	bw = n-l
	bk = n-2*l

	for kk = 1:(2*l)
		for kkk=1:l
			rows[ii] = bw+  kkk
			columns[ii] =bk+ kk
			ii = ii + 1
		end
	end

	for k=2:(v-1)
		bk = k*l
		bw = bk-l
		for tt=1:l
			rows[ii]=bw
			columns[ii]=bk+tt
			ii = ii+1
		end
	end


    A = sparse(rows,columns,vall)

    r =size(temp[1],1)

    for iii = 1:r
    	A[temp[1][iii],temp[2][iii]] = temp[3][iii]
    end

    return A,n,l
end


function read_vector(name)
    temp2 = readdlm(name,' ')
    n = Int(temp2[1])
    b = temp2[2:n+1]

    return b
end

function multi_sparse(A,n,l)
	b = Vector{Float64}(n)
	v=Int(n/l)

		

			bas = 0
			for ii = 1:l
				sumT = 0.0
				for iii =1:(l+ii)
					sumT = sumT + A[bas+ii,bas+iii]
				end
				b[bas+ii] = sumT
			end

	for k =2:(v-1)

		
			bas = (k-1)*l
			for ii =1:l
				sumT = A[bas+ii,bas]
				for iii = 1:(l+ii)
					sumT =sumT + A[bas+ii,bas+iii]
				end
				b[bas+ii] = sumT
			end
		
	end
			bas = (v-1)*l
			for ii =1:l
				sumT = A[bas+ii,bas]
				for iii = 1:l
					sumT =sumT + A[bas+ii,bas+iii]
				end
				b[bas+ii] = sumT
			end

	return b
end


function gausSimple(mat,vec,typ,ou)

	A, n, l  = read_matrix(mat)
	v = n/l

	if typ==1
    	b = read_vector(vec)
	else
		b = multi_sparse(A,n,l)
	end

@time begin
	base = 0

	while base != (n-l)
		#Przerobilem juz base
		#Ruguje A, oprocz ostatniej kolumny
	    for k = 1:(l-1)
	        p=base+k


	        m=A[p,p]
	        #print("Tut1")

	        for w = (k+1):l
	            q = A[base+w,p]/m # wspolczynnik #Poprawka
	            A[base+w,p]=0.0
				b[base+w] = b[base+w] - q*b[p]
	            #print("Tut2")

	            for it = (p+1):(base+l)
	                A[base+w,it] = A[base+w,it]-q*A[p,it]
	            end

	#C

	            for it = 1:l #Bylo wczesnie k
	                A[base+w,it+l+base] =A[base+w,it+l+base]-q*A[p,it+l+base]
	            end
	        end
	    end
	#	println("Obecny stan")
	#	println(A)
	#B
	    k=l
	    base = base +l
		
		m=A[base,base]
	    for w = 1:l
	        q = A[base+w,base]/m
	        A[base+w,base]=0.0
			b[base+w] = b[base+w] - q*b[base]
	        for it = 1:l
	            A[base+w,base+it] = A[base+w,base+it]-q*A[base,base+it]
	        end

	    end
	#println((norm((full(A)\b)-ones(n)))/norm(ones(n)))
	end
	#c=full(A)
	#println("RozwD")
	#println((norm((c\b)-ones(n)))/norm(ones(n)))
	for k = 1:(l-1)
	    p=base+k
		
	    m=A[p,p]

	    for w = (k+1):l
	        q = A[base+w,p]/m
	        A[base+w,p]=0.0
			b[base+w] = b[base+w]-q*b[p]
	        for it = (p+1):(base+l)
	            A[base+w,it] = A[base+w,it]-q*A[p,it]
	        end
	    end
	end
	#Sprawdzenie troj
	#c = full(A)
	#for i= 1:n
	#	for j = 1:(i-1)
	#		if c[i,j] != 0.0
	#			print(i)
	#			print(" ")
	#			print(j)
	#			println("Kurdee")
	#		end
	#	end
	#end



	k = n
	
	while k>=2*l

		b[k] = b[k]/A[k,k]
		for ii=1:(2*l-1)
			
			b[k-ii] = b[k-ii]- (A[k-ii,k])*b[k]
		end
		
		k = k -1
	end

	while k>1

		b[k] = b[k]/A[k,k]
		for ii=(-k+1):(-1)
			
			b[-ii] = b[-ii]- (A[-ii,k])*b[k]
		end

		k = k-1
	end
	
	b[1] = b[1]/A[1,1]



end
	z = ones(size(b))
	print(norm(b - z) / norm(z))
	if typ==1
    		writedlm(ou,b)
	else
		writedlm(ou,vcat([(norm(b - z) / norm(z))],b))
	end
end

function swap(A,w1,w2,l,n)
	if w1 %l ==0
		if w1 == n-l
			en = l
		else
			en = 2*l
		end
		for i= w1:(w1+en)
			temp =A[w1,i]

			A[w1,i] = A[w2,i]
			A[w2,i] = temp
		end
	else
		if w1>n-l
			en = n
		else
			en = (w1-(w1%l)+2*l)
		end
		for i=w1:en
			temp =A[w1,i]

			A[w1,i] = A[w2,i]
			A[w2,i] = temp
		end
	end

end

function find_max(A,k,l)

	maxW=k
	max = abs(A[k,k])

	#Mozna poprawic, by mniej sprawdzal
	r = k % (2*l)
	en = k+ (l*2-r)#Zmiana znakow
	for it = k+1:en
		if (abs(A[it,k])>max)
			maxW = it
			max = abs(A[it,k])
		end
	end

	return maxW
end

function proper(A,k,l,b,n)
	#println(proper)
	w2 = find_max(A,k,l)
	if w2 != k
		swap(A,k,w2,l,n)
		temp = b[k]
		b[k] = b[w2]
		b[w2] = temp
	end

end

function gausChoice(mat,vec,typ,ou)

	A, n, l  = read_matrix_swap(mat)
	v = n/l

	if typ==1
    	b = read_vector(vec)
	else
		b = multi_sparse(A,n,l)
	end

@time begin
	base = 0

	while base != (n-l)
		#Przerobilem juz base
		#Ruguje A, oprocz ostatniej kolumny
	    for k = 1:(l-1)
	        p=base+k
	
			proper(A,p,l,b,n)

	        m=A[p,p]
	        #print("Tut1")

	        for w = (k+1):l
	            q = A[base+w,p]/m # wspolczynnik #Poprawka
	            A[base+w,p]=0.0
				b[base+w] = b[base+w] - q*b[p]
	            #print("Tut2")

	            for it = (p+1):(base+l)
	                A[base+w,it] = A[base+w,it]-q*A[p,it]
	            end

	#C

	            for it = 1:l #Bylo wczesnie k
	                A[base+w,it+l+base] =A[base+w,it+l+base]-q*A[p,it+l+base]
	            end
	        end
	    end
	#	println("Obecny stan")
	#	println(A)
	#B
	    k=l
	    base = base +l
		proper(A,base,l,b,n)
		m=A[base,base]
	    for w = 1:l
	        q = A[base+w,base]/m
	        A[base+w,base]=0.0
			b[base+w] = b[base+w] - q*b[base]
	        for it = 1:l
	            A[base+w,base+it] = A[base+w,base+it]-q*A[base,base+it]
	        end

	    end
	#println((norm((full(A)\b)-ones(n)))/norm(ones(n)))
	end
	#c=full(A)
	#println("RozwD")
	#println((norm((c\b)-ones(n)))/norm(ones(n)))
	for k = 1:(l-1)
	    p=base+k
		proper(A,p,l,b,n)
	    m=A[p,p]

	    for w = (k+1):l
	        q = A[base+w,p]/m
	        A[base+w,p]=0.0
			b[base+w] = b[base+w]-q*b[p]
	        for it = (p+1):(base+l)
	            A[base+w,it] = A[base+w,it]-q*A[p,it]
	        end
	    end
	end
	#Sprawdzenie troj
	#c = full(A)
	#for i= 1:n
	#	for j = 1:(i-1)
	#		if c[i,j] != 0.0
	#			print(i)
	#			print(" ")
	#			print(j)
	#			println("Kurdee")
	#		end
	#	end
	#end



	k = n
	
	while k>=2*l

		b[k] = b[k]/A[k,k]
		for ii=1:(2*l-1)
			
			b[k-ii] = b[k-ii]- (A[k-ii,k])*b[k]
		end
		
		k = k -1
	end

	while k>1

		b[k] = b[k]/A[k,k]
		for ii=(-k+1):(-1)
			
			b[-ii] = b[-ii]- (A[-ii,k])*b[k]
		end

		k = k-1
	end
	
	b[1] = b[1]/A[1,1]



end
	z = ones(size(b))
	print(norm(b - z) / norm(z))
	if typ==1
    		writedlm(ou,b)
	else
		writedlm(ou,vcat([(norm(b - z) / norm(z))],b))
	end
end

function LUSimple(mat)

	A, n, l  = read_matrix(mat)
	v = n/l
	if typ==1
    		b = read_vector(vec)
	else
		b = multi_sparse(A,n,l)
	end
	

	z =ones(n)
	base = 0

	while base != (n-l)

	    for k = 1:(l-1)
	        p=base+k
	        m=A[p,p]


	        for w = (k+1):l
	            q = A[base+w,p]/m # wspolczynnik #Poprawka
	            A[base+w,p]=q
				#b[base+w] = b[base+w] - q*b[p]
	            for it = (p+1):(base+l)
	                A[base+w,it] = A[base+w,it]-q*A[p,it]
	            end

	#C

	            for it = 1:k
	                A[base+w,it+l+base] =A[base+w,it+l+base]-q*A[p,it+l+base]
	            end
	        end
	    end

	#B
	    k=l
	    base = base +l
		#proper(A,base,l,b)
		m=A[base,base]
	    for w = 1:l
	        q = A[base+w,base]/m
	        A[base+w,base]=q
			#b[base+w] = b[base+w] - q*b[base]
	        for it = 1:l
	            A[base+w,base+it] = A[base+w,base+it]-q*A[base,base+it]
	        end

	    end

	end

	for k = 1:(l-1)
	    p=base+k
		#proper(A,p,l,b)
	    m=A[p,p]

	    for w = (k+1):l
	        q = A[base+w,p]/m
	        A[base+w,p]=q
			#b[base+w] = b[base+w] - q*b[p]
	        for it = (p+1):(base+l)
	            A[base+w,it] = A[base+w,it]-q*A[p,it]
	        end
	    end
	end

	#println(b)



end

function swap1(A,w1,w2,l,n)
    st1 = Int(floor((w1-1)/(2*l)))
    st1 = st1*2*l
	if st1 == n-2*l
		for i= (st1+1):(st1+l*2)
			temp =A[w1,i]


			A[w1,i] = A[w2,i]
			A[w2,i] = temp
		end
	else
		for i= (st1+1):(st1+l*3)
			temp =A[w1,i]


			A[w1,i] = A[w2,i]
			A[w2,i] = temp
		end
	end
end

function find_max1(A,k)
    maxW=k
    max = abs(A[k,k])

    #Mozna poprawic, by mniej sprawdzal
    r = k % (2*l)
    en = k+ (l*2-r)#Zmiana znakow
    for it = k+1:en
        if (abs(A[it,k])>max)
            maxW = it
            max = abs(A[it,k])
        end
    end

    return maxW
end

function proper1(A,k,l,n)
    w2 = find_max1(A,k)

    if w2 != k

		swap1(A,k,w2,l,)

    end
end

function LUChoice(mat)

	A, n, l  = read_matrix_swap(mat)
	v = n/l

	if typ==1
    	b = read_vector(vec)
	else
		b = multi_sparse(A,n,l)
	end

	params = Vector{Vector{Tuple{Float64,Int}}}(n)
	places=Vector{Int}(n)

	for ii=1:n
		places[ii] = 1
	end

	for ii =1:n
		params[ii] =Vector{Tuple{Float64,Int}}(2*l)
	end


	base=0
	while base != (n-l)

	    for k = 1:(l-1)
	        p=base+k
			proper2(A,p,l,b,params,places,n)
	        m=A[p,p]


	        for w = (k+1):l
	            q = A[base+w,p]/m # wspolczynnik #Poprawka
	            #A[base+w,p]=q
				#println("ASASASAS")
				params[base+w][places[base+w]] = (q,p)
				#println("GDAGDA")
				places[base+w] = places[base+w] + 1
			
	            for it = (p+1):(base+l)
	                A[base+w,it] = A[base+w,it]-q*A[p,it]
	            end

	#C

	            for it = 1:l
	                A[base+w,it+l+base] =A[base+w,it+l+base]-q*A[p,it+l+base]
	            end
	        end
	    end

	#B
	    k=l
	    base = base +l
		proper2(A,base,l,b,params,places,n)
		m=A[base,base]
	    for w = 1:l
	        q = A[base+w,base]/m
	        #A[base+w,base]=q
			params[base+w][places[base+w]] = (q,base)
			places[base+w]  = places[base+w] + 1
			#b[base+w] = b[base+w] - q*b[base]
	        for it = 1:l
	            A[base+w,base+it] = A[base+w,base+it]-q*A[base,base+it]
	        end

	    end
	#println(full(A))
	end

	for k = 1:(l-1)
	    p=base+k
		proper2(A,p,l,b,params,places,n)
	    m=A[p,p]

	    for w = (k+1):l
	        q = A[base+w,p]/m
	        #A[base+w,p]=q
			params[base+w][places[base+w]] = (q,p)
			places[base+w] = places[base+w]+ 1

			#b[base+w] = b[base+w] - q*b[p]
	        for it = (p+1):(base+l)
	            A[base+w,it] = A[base+w,it]-q*A[p,it]
	        end
	    end
		#println(full(A))
	end
	#println("Obecny stan")
	#println(full(A))
	#println(b)

	#for ii = 1:n
	#	for iii = 1:(places[ii]-1)
	#		print(ii)
	#		print(" ")
	#		println(params[ii][iii])
	#	end
	#end

	k = 1

end


function swap2(A,w1,w2,l,ll,pl,n)
    st1 = Int(floor((w1-1)/(2*l)))
    st1 = st1*2*l

	#w1 = k
	temp1 = ll[w1]
	ll[w1] = ll[w2]
	ll[w2] = temp1

	temp = pl[w1]
	pl[w1] = pl[w2]
	pl[w2] = temp

	if w1 %l ==0
		if w1 == n-l
			en = l
		else
			en = 2*l
		end
		for i= w1:(w1+en)
			temp =A[w1,i]

			A[w1,i] = A[w2,i]
			A[w2,i] = temp
		end
	else
		if w1>n-l
			en = n
		else
			en = (w1-(w1%l)+2*l)
		end
		for i=w1:en
			temp =A[w1,i]

			A[w1,i] = A[w2,i]
			A[w2,i] = temp
		end
	end
end

function find_max2(A,k,l)
    maxW=k
    max = abs(A[k,k])

    #Mozna poprawic, by mniej sprawdzal
    r = k % (2*l)
    en = k+ (l*2-r)#Zmiana znakow
    for it = k+1:en
        if (abs(A[it,k])>max)
            maxW = it
            max = abs(A[it,k])
        end
    end

    return maxW
end

function proper2(A,k,l,b,ll,pl,n)
    w2 = find_max2(A,k,l)

    if w2 != k
		swap2(A,k,w2,l,ll,pl,n)
		temp = b[k]
		b[k] = b[w2]
		b[w2] = temp
    end
end


function LUChoiceSolve(mat,vec,typ,ou)

	A, n, l  = read_matrix_swap(mat)
	v = n/l

	if typ==1
    	b = read_vector(vec)
	else
		b = multi_sparse(A,n,l)
	end

	params = Vector{Vector{Tuple{Float64,Int}}}(n)
	places=Vector{Int}(n)

	for ii=1:n
		places[ii] = 1
	end

	for ii =1:n
		params[ii] =Vector{Tuple{Float64,Int}}(2*l)
	end

@time begin
	base=0
	while base != (n-l)

	    for k = 1:(l-1)
	        p=base+k
			proper2(A,p,l,b,params,places,n)
	        m=A[p,p]


	        for w = (k+1):l
	            q = A[base+w,p]/m # wspolczynnik #Poprawka
	            #A[base+w,p]=q
				#println("ASASASAS")
				params[base+w][places[base+w]] = (q,p)
				#println("GDAGDA")
				places[base+w] = places[base+w] + 1
			
	            for it = (p+1):(base+l)
	                A[base+w,it] = A[base+w,it]-q*A[p,it]
	            end

	#C

	            for it = 1:l
	                A[base+w,it+l+base] =A[base+w,it+l+base]-q*A[p,it+l+base]
	            end
	        end
	    end

	#B
	    k=l
	    base = base +l
		proper2(A,base,l,b,params,places,n)
		m=A[base,base]
	    for w = 1:l
	        q = A[base+w,base]/m
	        #A[base+w,base]=q
			params[base+w][places[base+w]] = (q,base)
			places[base+w]  = places[base+w] + 1
			#b[base+w] = b[base+w] - q*b[base]
	        for it = 1:l
	            A[base+w,base+it] = A[base+w,base+it]-q*A[base,base+it]
	        end

	    end
	#println(full(A))
	end

	for k = 1:(l-1)
	    p=base+k
		proper2(A,p,l,b,params,places,n)
	    m=A[p,p]

	    for w = (k+1):l
	        q = A[base+w,p]/m
	        #A[base+w,p]=q
			params[base+w][places[base+w]] = (q,p)
			places[base+w] = places[base+w]+ 1

			#b[base+w] = b[base+w] - q*b[p]
	        for it = (p+1):(base+l)
	            A[base+w,it] = A[base+w,it]-q*A[p,it]
	        end
	    end
		#println(full(A))
	end
	#println("Obecny stan")
	#println(full(A))
	#println(b)

	#for ii = 1:n
	#	for iii = 1:(places[ii]-1)
	#		print(ii)
	#		print(" ")
	#		println(params[ii][iii])
	#	end
	#end

	k = 1

	#Rozwiazuje dolna
	for k=1:n
		for ii=(k+1):n
			iii = 1
			while iii<places[ii]

				(a1,a2) = params[ii][iii]
				if a2==k
					b[ii] = b[ii] - b[k]*a1
					break
				end
				iii = iii + 1
			end
		end
	end


	#println("Po dolnej")
	#println(b)
	# Rozwiazuje gorna
	k = n
	while k>l*2
		b[k] = b[k]/A[k,k]
		ii =k-1
		while ii >=(k-l*2)
			b[ii] = b[ii]- A[ii,k]*b[k]
			ii = ii-1
		end
		k = k-1

	end

	while k>=1
		ii = k-1
		b[k] = b[k]/A[k,k]
		while ii >=1
			b[ii] = b[ii]- A[ii,k]*b[k]
			ii = ii-1
		end
		k = k-1

	end
	#println(full(A))
	#println(b)

	k = n

end
	z = ones(size(b))
	println(norm(b - z) / norm(z))

	if typ==1
    		writedlm(ou,b)
	else
		writedlm(ou,vcat([(norm(b - z) / norm(z))],b))
	end

end


function LUSimpleSolve(mat,vec,typ,ou)

	A, n, l  = read_matrix(mat)
	v = n/l
	if typ==1
    		b = read_vector(vec)
	else
		b = multi_sparse(A,n,l)
	end
	

	z =ones(n)
@time begin
	base = 0

	while base != (n-l)

	    for k = 1:(l-1)
	        p=base+k
	        m=A[p,p]


	        for w = (k+1):l
	            q = A[base+w,p]/m # wspolczynnik #Poprawka
	            A[base+w,p]=q
				#b[base+w] = b[base+w] - q*b[p]
	            for it = (p+1):(base+l)
	                A[base+w,it] = A[base+w,it]-q*A[p,it]
	            end

	#C

	            for it = 1:k
	                A[base+w,it+l+base] =A[base+w,it+l+base]-q*A[p,it+l+base]
	            end
	        end
	    end

	#B
	    k=l
	    base = base +l
		#proper(A,base,l,b)
		m=A[base,base]
	    for w = 1:l
	        q = A[base+w,base]/m
	        A[base+w,base]=q
			#b[base+w] = b[base+w] - q*b[base]
	        for it = 1:l
	            A[base+w,base+it] = A[base+w,base+it]-q*A[base,base+it]
	        end

	    end

	end

	for k = 1:(l-1)
	    p=base+k
		#proper(A,p,l,b)
	    m=A[p,p]

	    for w = (k+1):l
	        q = A[base+w,p]/m
	        A[base+w,p]=q
			#b[base+w] = b[base+w] - q*b[p]
	        for it = (p+1):(base+l)
	            A[base+w,it] = A[base+w,it]-q*A[p,it]
	        end
	    end
	end

	#println(b)

	k = 1

	#Rozwiazuje dolna

	while k<(n-l)
		if (k%l!=0)
			for ii=1:(l-(k%l))
				b[k+ii] = b[k+ii]- A[k+ii,k]*b[k]
			end
		else
			for ii=1:l
				b[k+ii] = b[k+ii]- A[k+ii,k]*b[k]
			end
		end
		#println(k)
		#println(b)
		k = k +1
	end

	for k = (n-l):(n-1)
		for ii =1:(n-k)
			b[k+ii] = b[k+ii]- A[k+ii,k]*b[k]
		end
	end


	# Rozwiazuje gorna


	k=n
	while k>l

		b[k] = b[k]/A[k,k]
		ii =k-1
		while ii >=(k-l)
			b[ii] = b[ii]- A[ii,k]*b[k]
			ii = ii-1
		end
		k = k-1
		#println(k+1)
		#println(b)
	end

	while k>=1
		ii = k-1
		b[k] = b[k]/A[k,k]
		while ii >=1
			b[ii] = b[ii]- A[ii,k]*b[k]
			ii = ii-1
		end
		#println(k)
		#println(b)
		k = k-1

	end
	#println(full(A))
	#println(b)

	k = n

end
	#println(b)
	z = ones(size(b))
	println(norm(b - z) / norm(z))
	if typ==1
    		writedlm(ou,b)
	else
		writedlm(ou,vcat([(norm(b - z) / norm(z))],b))
	end

end
end
